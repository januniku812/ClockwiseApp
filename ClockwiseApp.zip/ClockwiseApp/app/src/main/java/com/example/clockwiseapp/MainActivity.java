package com.example.clockwiseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DigitalClock;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.*;

import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONException;
import org.json.simple.parser.ParseException;


public class MainActivity extends AppCompatActivity {
    ArrayList<TodoItem> todoItems;
    ListView todoListView;
    TodoItemAdapter todoItemAdapter;

    public void addItemDialog(){
        androidx.appcompat.app.AlertDialog.Builder builder =
                new androidx.appcompat.app.AlertDialog.Builder
                        (MainActivity.this, R.style.AlertDialogCustom);
        View view = LayoutInflater.from(MainActivity.this).inflate(
                R.layout.add_item_dialog,
                (ViewGroup) findViewById(R.id.layoutDialogContainer)
        );
        builder.setView(view);
        EditText nameEditText = view.findViewById(R.id.add_todo_item_name);
        Button enterButton = view.findViewById(R.id.enterButton);
        Button cancelButton = view.findViewById(R.id.cancel_button);
        final androidx.appcompat.app.AlertDialog alertDialog = builder.create();
        enterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!nameEditText.getText().toString().isEmpty()){
                    try {
                        QueryUtils.addTodoItem(String.valueOf(nameEditText.getText()), getApplicationContext());
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    update();
                    alertDialog.dismiss();

                }
            }
        });
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
    }

    public void update(){
        try {
            todoItems = QueryUtils.loadTodoItems(getApplicationContext());
        } catch (JSONException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        todoItemAdapter = new TodoItemAdapter(getApplicationContext(), todoItems);
        todoListView.setAdapter(todoItemAdapter);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        todoListView = findViewById(R.id.todo_list_view);
        try {
            todoItems = QueryUtils.loadTodoItems(getApplicationContext());
        } catch (JSONException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        todoItemAdapter = new TodoItemAdapter(getApplicationContext(), todoItems);
        Constants.jsonStr = PreferenceManager.getDefaultSharedPreferences(this).getString("jsonStr", "{\n" +
                "\"todo_items\":[]\n" +
                "}");
        todoListView.setAdapter(todoItemAdapter);
        ImageButton addItemButton = findViewById(R.id.add_item_button);
        ImageButton notificationButton = findViewById(R.id.notifications_button);
        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, com.example.clockwiseapp.NotificationsPage.class);
                startActivity(intent);
            }
        });

        ImageButton timerButton = findViewById(R.id.timer_button);
        DigitalClock digitalClock = (DigitalClock) findViewById(R.id.digital_clock);
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItemDialog();
            }
        });

        timerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, com.example.clockwiseapp.TimerActivity.class);
                startActivity(intent);
            }
        });

        todoListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Button doneButton = view.findViewById(R.id.done_button);
                TodoItem todoItem = todoItemAdapter.getItem(position);
                doneButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            QueryUtils.setTodoItemAsComplete(todoItem.getName(), getApplicationContext());
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        } catch (ParseException e) {
                            throw new RuntimeException(e);
                        }
                        update();

                    }
                });
            }
        });


    }
}