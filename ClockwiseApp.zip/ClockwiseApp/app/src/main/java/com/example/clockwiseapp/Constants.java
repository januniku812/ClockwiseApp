package com.example.clockwiseapp;

public class Constants {
    public static String jsonStr = "";
}
